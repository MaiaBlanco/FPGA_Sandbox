/*
 * Author: Mark Blanco
 * Date: Sept 4 2017
 * Description: Matmul implementation with single thread using doubles.
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
// To use functions from OpenMP:
#include <omp.h>
// To use Intel SSE2 intrinsics:
//#include <emmintrin.h>
//#include <immintrin.h>

#define MAT_SIZE 4096
//#define BLOCK_SIZE 128
//#define IDX2C(i,j) (((j)*(MAT_SIZE))+(i)) // defined as shortcut for indexing into matrix

double A [MAT_SIZE][MAT_SIZE] = {{0}};
double B [MAT_SIZE][MAT_SIZE] = {{0}};
double C [MAT_SIZE][MAT_SIZE] = {{0}};

void printMatC()
{
	int i, j;
	for (i = 0; i < MAT_SIZE; i++)
	{
		for (j = 0; j < MAT_SIZE; j++)
		{
			printf("%.2f ", C[i][j]);
		}
		printf("\n");
	}
}

void randInitMats()
{
	int i, j;
  	for (i = 0; i < MAT_SIZE; i++)
	{
		for (j = 0; j < MAT_SIZE; j++){
		  A[i][j] = rand() / (double)RAND_MAX;
		  B[i][j] = rand() / (double)RAND_MAX;
		}
	}
}

void resetC(){
	// Reset C values to 0:
	int i, j;
	for (i = 0; i < MAT_SIZE; i++)
	{
		for (j = 0; j < MAT_SIZE; j++)
		{
			C[i][j] = 0;
		}
	}
}

// Of non-blocked approaches, this is the fastest version
// I think the order of loop iterations here w.r.t the MAC line 
// affects runtime positively because first indices for the matrices change as infrequently as possible,
// thereby keeping those contiguos slices of memory in cache for longer. Keeping the second index the same
// probably wouldn't have the same effect since changing the second index will hop between contiguous
// sections of memory.
void matmulv3()
{
	int i,j,k;
	for (i = 0; i < MAT_SIZE; i ++)
	{
		for (k = 0; k < MAT_SIZE; k ++)
		{
			for (j = 0; j < MAT_SIZE; j ++)
			{
				C[i][j] += A[i][k] * B[k][j];
			}
		}
	}
}

int main()
{
	int i;
  	clock_t start[10], end[10] = {0};
		double omp_start[10], omp_end[10] = {0};
  	double time_elapsed[10] = {0};
		double omp_time_elapsed[10] = {0};
  	double average = 0;
		double omp_average = 0;
  	double std_dev = 0;
		double omp_std_dev = 0;
  	printf("Initializing random matrix values.\n");
  	// initialize random values to the matrices:
  	randInitMats();
	printf("Starting 10 matmul runs.\n");
	for (i = 0; i < 10; i++)
	{
		// Reset values in the matrix
		resetC();
		// Start the timers and perform MATMUL
		start[i] = clock();
		omp_start[i] = omp_get_wtime();
		matmulv3();
		end[i] = clock();
		omp_end[i] = omp_get_wtime();
		// End timers and print the result for that run
		time_elapsed[i] = ((double)end[i] - (double)start[i]) / CLOCKS_PER_SEC;
		omp_time_elapsed[i] = (omp_end[i] - omp_start[i]);
		printf("Performed MATMUL operation with %d x %d matrices in %f seconds (time library measurement).\n OMP wall time was %f seconds.\n", 
			MAT_SIZE, MAT_SIZE, time_elapsed[i], omp_time_elapsed[i] );
		average	+= time_elapsed[i];
		omp_average += (double)omp_time_elapsed[i];
	}
	average	/= 10;
	omp_average /= 10;
	for (i = 0; i < 10; i ++)
	{
		std_dev += pow(time_elapsed[i] - average, 2);
		omp_std_dev += pow(omp_time_elapsed[i] - omp_average, 2);
	}
	std_dev /= 10;
	omp_std_dev /= 10;
	// Print final overall statistics
	printf("Average ctime-measured time: %f seconds\n\tStd deviation: %f seconds.\n", average, std_dev);
	printf("Average OMP-measured wall time: %f seconds.\n\tStd dev: %f seconds\n.", omp_average, omp_std_dev);
	return 0;
}

